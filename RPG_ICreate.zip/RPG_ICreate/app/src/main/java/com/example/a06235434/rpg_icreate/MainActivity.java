package com.example.a06235434.rpg_icreate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void chamaTelaPrincipal(View v) {
        setContentView(R.layout.activity_main);
    }

    public void chamaTelaFirst(View v) {
        setContentView(R.layout.activity_first);
    }

    public void chamaTelaView(View v) {
        setContentView(R.layout.activity_view);
    }

    public void chamaTelaNew(View v) {
        setContentView(R.layout.activity_new);
    }

    public void chamaTelaCreate(View v) {
        setContentView(R.layout.activity_create);
    }


}
